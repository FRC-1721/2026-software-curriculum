package frc.robot.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * WEEK 2 — unit tests for {@link RobotMath}. Run them with:  ./gradlew test
 * (WPILib projects include JUnit 5 on the test classpath already.)
 */
class RobotMathTest {
  private static final double DELTA = 1e-9;

  @Test
  void deadbandInsideZoneReturnsZero() {
    assertEquals(0.0, RobotMath.deadband(0.05, 0.1), DELTA);
  }

  @Test
  void deadbandRescalesPositive() {
    assertEquals(0.5, RobotMath.deadband(0.55, 0.1), DELTA);
  }

  @Test
  void deadbandRescalesNegative() {
    assertEquals(-0.5, RobotMath.deadband(-0.55, 0.1), DELTA);
  }

  @Test
  void deadbandReachesFullScale() {
    assertEquals(1.0, RobotMath.deadband(1.0, 0.1), DELTA);
    assertEquals(-1.0, RobotMath.deadband(-1.0, 0.1), DELTA);
  }

  @Test
  void clampConstrainsToRange() {
    assertEquals(1.0, RobotMath.clamp(5.0, 0.0, 1.0), DELTA);
    assertEquals(0.0, RobotMath.clamp(-5.0, 0.0, 1.0), DELTA);
    assertEquals(0.5, RobotMath.clamp(0.5, 0.0, 1.0), DELTA);
  }

  @Test
  void rotationsAndMetersRoundTrip() {
    double wheelDiameterMeters = 0.1016; // 4 inch wheel
    double meters = RobotMath.rotationsToMeters(3.0, wheelDiameterMeters);
    assertEquals(3.0, RobotMath.metersToRotations(meters, wheelDiameterMeters), DELTA);
  }
}
