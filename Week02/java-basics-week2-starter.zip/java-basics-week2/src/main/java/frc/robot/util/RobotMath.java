package frc.robot.util;

/**
 * WEEK 2 — a small collection of pure-Java math helpers for robot code.
 *
 * Everything here is plain Java (no WPILib), so it is easy to reason about and
 * to unit-test. WPILib ships equivalents in edu.wpi.first.math.MathUtil
 * (applyDeadband, clamp) — we write our own here to learn how they work.
 *
 * This is a "utility class": it holds only static methods and is never
 * instantiated, so the constructor is private.
 */
public final class RobotMath {

  private RobotMath() {}

  /**
   * Removes joystick jitter near the center, then rescales so the output still
   * reaches full range. Assumes {@code value} is in [-1, 1] and
   * {@code 0 <= deadband < 1}.
   *
   * <p>Example: with a 0.1 deadband, an input of 0.55 returns 0.5 — the output
   * ramps smoothly from 0 at the edge of the deadband up to 1.0 at full stick.
   *
   * @param value    the raw axis value, in [-1, 1]
   * @param deadband the size of the dead zone, in [0, 1)
   * @return 0 inside the dead zone, otherwise the rescaled value in [-1, 1]
   */
  public static double deadband(double value, double deadband) {
    if (Math.abs(value) > deadband) {
      if (value > 0.0) {
        return (value - deadband) / (1.0 - deadband);
      } else {
        return (value + deadband) / (1.0 - deadband);
      }
    }
    return 0.0;
  }

  /**
   * Constrains {@code value} to the range [low, high].
   *
   * @param value the number to constrain
   * @param low   the lower bound (must be <= high)
   * @param high  the upper bound
   * @return value clamped into [low, high]
   */
  public static double clamp(double value, double low, double high) {
    return Math.max(low, Math.min(high, value));
  }

  /**
   * Converts wheel rotations to distance traveled along the ground.
   *
   * @param rotations          number of wheel rotations
   * @param wheelDiameterMeters wheel diameter in meters
   * @return distance in meters
   */
  public static double rotationsToMeters(double rotations, double wheelDiameterMeters) {
    return rotations * Math.PI * wheelDiameterMeters;
  }

  /**
   * Converts a ground distance to the wheel rotations needed to cover it.
   * The inverse of {@link #rotationsToMeters(double, double)}.
   *
   * @param meters             distance in meters
   * @param wheelDiameterMeters wheel diameter in meters (must be > 0)
   * @return number of wheel rotations
   */
  public static double metersToRotations(double meters, double wheelDiameterMeters) {
    return meters / (Math.PI * wheelDiameterMeters);
  }
}
