package frc.robot;

import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.XboxController;
import frc.robot.util.RobotMath;

/**
 * WEEK 2 — using the {@link RobotMath} helper you wrote on a real joystick axis.
 *
 * This is the integration step: your pure-Java helper is now called ~50x/second
 * with a live controller value. We print at a slower rate so the console is
 * readable (printing every loop would flood it — remember Week 1!).
 */
public class Robot extends TimedRobot {

  private final XboxController driver = new XboxController(0);
  private int loops = 0;

  public Robot() {}

  @Override
  public void teleopInit() {
    loops = 0;
    System.out.println("Teleop started — push the left stick to see deadband at work.");
  }

  @Override
  public void teleopPeriodic() {
    double rawY = driver.getLeftY();
    double commanded = RobotMath.deadband(rawY, 0.1);

    loops++;
    if (loops % 25 == 0) { // about twice per second
      System.out.printf("raw = %+.2f   after deadband = %+.2f%n", rawY, commanded);
    }
  }
}
