# Week 2 Starter / Reference — Java for FRC, part 1

FRC 1721 · WPILib 2026 · Java. Reference project for **Week 2: values, methods,
objects**. Everything here builds on a Timed Robot project and runs in
simulation — no physical robot needed.

## What you're learning
How to write and *test* a small Java class, then call it from robot code. The
star of the week is `RobotMath` — a pure-Java helper with `deadband`, `clamp`,
and `rotationsToMeters`.

## What's in here
```
src/main/java/frc/robot/
├── Robot.java                 calls RobotMath.deadband() on a live joystick axis
├── Main.java                  entry point — do not edit
└── util/RobotMath.java        the helper class you build this week
src/test/java/frc/robot/
└── util/RobotMathTest.java    JUnit 5 tests for RobotMath
```

## The lab
1. Write (or complete) `RobotMath` — small static methods, no WPILib needed.
2. Run the tests:  **`./gradlew test`**  (Windows: `gradlew test`). All should pass.
3. Wire it in: `Robot.java` reads the left-stick Y value and prints it before and
   after `RobotMath.deadband(...)`. Simulate, set state to **Teleoperated**, push
   the stick, and watch the dead zone remove jitter near center.

> **Tip:** WPILib already ships `edu.wpi.first.math.MathUtil.applyDeadband` and
> `MathUtil.clamp`. We write our own this week to learn how they work; on the real
> robot you can use either.

## Using this pack
- **Generate fresh (recommended):** create a `Template → java → Timed Robot`
  project, then drop these `src/` files in. Generating locally pins the exact
  GradleRIO/WPILib 2026 version and creates the Gradle wrapper.
- **Reference branch:** or clone the repo's Week 2 reference (which includes the
  generated Gradle wrapper) and run it directly.

Team number is set to **1721** in `.wpilib/wpilib_preferences.json`.

## Verified
`RobotMath` and `RobotMathTest` compile clean (`javac -Xlint:all`, Java 17) and
the tested cases pass. `Robot.java` is checked against the WPILib 2026 API.
