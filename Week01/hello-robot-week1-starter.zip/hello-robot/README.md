# Hello, Robot — Week 1 Starter / Reference

The reference project for **Week 1** of the FRC Java 12-week program:
*Environment, tooling & "Hello, Robot."* It builds, runs in the WPILib
simulator, and prints a message — no physical robot required.

Target: **WPILib 2026**, Java, Timed Robot.

---

## Two ways to use this pack

**Option A — Generate fresh (recommended for students).**
This is the actual Week 1 lab. In VS Code:
`Ctrl/Cmd+Shift+P` → **WPILib: Create a new project** → `Template` → `java` →
`Timed Robot`. Then compare your `Robot.java` to the one in this pack and add the
`System.out.println(...)` in `teleopInit()`. Generating locally is important —
it pins the exact GradleRIO/WPILib 2026 version installed on your machine and
creates the Gradle wrapper.

**Option B — Use this as the finished reference.**
Mentors: commit this project to the `week-01-reference` branch of the team repo
*after generating once locally* (so the Gradle wrapper and version-pinned
`build.gradle` are included). Students who fall behind can then clone that branch
and run it directly.

> **Why isn't this pack runnable as-is?** A buildable WPILib project also needs
> the **Gradle wrapper** (`gradlew`, `gradlew.bat`, `gradle/wrapper/…`), which the
> WPILib generator creates and pins to your installed version. Rather than ship a
> version that might not match your install, this pack gives you the source and
> config to drop into a freshly generated project. See the note at the top of
> `build.gradle`.

---

## What's in here

```
hello-robot/
├── src/main/java/frc/robot/
│   ├── Robot.java   ← the file you edit; heavily commented for Week 1
│   └── Main.java    ← entry point; do not change
├── .wpilib/
│   └── wpilib_preferences.json   ← language + year (2026) + team number
├── vendordeps/      ← empty this week; vendor libraries land here in Week 5
├── build.gradle     ← build recipe (reference; prefer the generated one)
├── settings.gradle
├── .gitignore       ← standard WPILib ignore list
├── README.md        ← this file
└── WPILIB-COMMANDS.md  ← cheat sheet of the commands you'll use
```

---

## The 60-second version of the lab

1. **Build:** `WPILib: Build Robot Code` → wait for `BUILD SUCCESSFUL`.
2. **Edit:** in `Robot.java`, put your name in the `teleopInit()` print line.
3. **Simulate:** `WPILib: Simulate Robot Code` → check **Sim GUI** → set Robot
   State to **Teleoperated** → see your message.
4. **Commit:** `git init && git add . && git commit -m "Week 1: Hello, Robot"`.

Full step-by-step (with checkpoints and troubleshooting) is in the **Week 1
student lab handout**.

---

## The one idea to remember

- `teleopInit()` runs **once** when Teleop starts → put one-time messages here.
- `teleopPeriodic()` runs **~50 times a second** while in Teleop → the robot's heartbeat.

Set your team number in `.wpilib/wpilib_preferences.json` (currently `9999`) or via
`WPILib: Set Team Number`.
