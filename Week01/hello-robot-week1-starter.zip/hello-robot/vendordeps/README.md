# vendordeps

This folder holds **vendor library** definitions (JSON files) — things like CTRE
Phoenix 6 and REVLib that let your code talk to specific motor controllers and
sensors.

It's **empty in Week 1** — we don't need any vendor libraries to print a message
in the simulator.

You'll add your first vendordeps in **Week 5**, when we bring in the swerve
drivetrain, using `WPILib: Manage Vendor Libraries`.
