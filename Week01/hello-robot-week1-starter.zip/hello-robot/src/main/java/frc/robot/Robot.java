package frc.robot;

import edu.wpi.first.wpilibj.TimedRobot;

/**
 * WEEK 1 — "Hello, Robot"
 *
 * This is the file you will spend the whole course in.
 *
 * THE ONE BIG IDEA:
 *   - Methods ending in "Init"     run ONCE, the moment a mode starts.
 *   - Methods ending in "Periodic" run about 50 TIMES PER SECOND (every ~20 ms)
 *     the whole time the robot is in that mode. That loop is the robot's heartbeat.
 *
 * The robot library (WPILib) calls these methods for you. You don't call them
 * yourself — you just fill them in.
 */
public class Robot extends TimedRobot {

  // A "field" — a variable that belongs to the whole class and remembers its
  // value between loops. We use it in the stretch goal below.
  private int loops = 0;

  /** The constructor runs once when the robot program starts up. */
  public Robot() {
    // Nothing to set up yet in Week 1.
  }

  /** Runs ~50x/second in EVERY mode. Good for things that must always happen. */
  @Override
  public void robotPeriodic() {}

  // ---------------------------------------------------------------------------
  // TELEOPERATED — this is the mode you'll enable in the simulator.
  // ---------------------------------------------------------------------------

  /** Runs ONCE when Teleop starts. Put one-time messages here. */
  @Override
  public void teleopInit() {
    // TODO(student): put YOUR name in the message below.
    System.out.println("Hello from <your name here>!");
  }

  /** Runs ~50x/second while in Teleop. */
  @Override
  public void teleopPeriodic() {
    // ----- STRETCH GOAL (uncomment to try) -----
    // Without the "if", this would print 50 times a second. The check makes it
    // print about once per second instead — a first taste of the loop being
    // useful instead of just noisy.
    //
    // loops++;
    // if (loops % 50 == 0) {
    //   System.out.println("Seconds enabled: " + (loops / 50));
    // }
  }

  // ---------------------------------------------------------------------------
  // Other modes — empty for now. We'll fill these in over the next weeks.
  // ---------------------------------------------------------------------------

  @Override
  public void autonomousInit() {}

  @Override
  public void autonomousPeriodic() {}

  @Override
  public void disabledInit() {}

  @Override
  public void disabledPeriodic() {}

  @Override
  public void testInit() {}

  @Override
  public void testPeriodic() {}

  /** Runs once when the SIMULATION starts (only when simulating, not on a real robot). */
  @Override
  public void simulationInit() {}

  @Override
  public void simulationPeriodic() {}
}
