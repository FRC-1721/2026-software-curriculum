package frc.robot;

import edu.wpi.first.wpilibj.RobotBase;

/**
 * Do NOT change this file.
 *
 * This is the true entry point of the program — the very first code that runs.
 * All it does is start your Robot class. If you rename the Robot class, change
 * the reference here too, but otherwise leave this file alone.
 */
public final class Main {
  private Main() {}

  public static void main(String... args) {
    RobotBase.startRobot(Robot::new);
  }
}
