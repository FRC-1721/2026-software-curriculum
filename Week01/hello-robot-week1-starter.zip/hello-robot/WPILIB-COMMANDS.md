# WPILib Command Cheat Sheet

Open the command palette with **`Ctrl+Shift+P`** (Windows) or **`Cmd+Shift+P`**
(Mac), then type the command. Or click the red **"W"** hexagon in the top-right
of VS Code.

| I want to… | Command |
|---|---|
| Start a new robot project | `WPILib: Create a new project` |
| Open an old (e.g. 2025) project | `WPILib: Import a WPILib 2025 Gradle Project` |
| Compile my code | `WPILib: Build Robot Code` |
| Run my code in the simulator | `WPILib: Simulate Robot Code` |
| Send my code to a real robot | `WPILib: Deploy Robot Code` *(Week 6+)* |
| Set our team number | `WPILib: Set Team Number` |
| See robot console output | `WPILib: Start Tool` → `Riolog`, or the VS Code terminal |
| Manage vendor libraries | `WPILib: Manage Vendor Libraries` *(Week 5+)* |

## Simulation quick reference

- After **Simulate Robot Code**, check **Sim GUI** when prompted.
- In the Sim GUI, use the **Robot State** panel: `Disabled` / `Autonomous` /
  `Teleoperated` / `Test`.
- Set state to **Teleoperated** to trigger `teleopInit()` and `teleopPeriodic()`.
- Console output shows in the VS Code integrated terminal.

## Git quick reference

```bash
git config --global user.name "Your Name"      # one time
git config --global user.email "you@email.com" # one time

git init                       # start tracking this project
git add .                      # stage all changes
git commit -m "message"        # save a snapshot
git remote add origin <URL>    # connect to the team repo (once)
git push -u origin wk1/yourname  # upload your branch
git log --oneline              # see your commits
git status                     # see what's changed
```
