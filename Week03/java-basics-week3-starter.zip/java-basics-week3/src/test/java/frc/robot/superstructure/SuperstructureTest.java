package frc.robot.superstructure;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * WEEK 3 — unit tests for the {@link Superstructure} state machine. Run with:
 * ./gradlew test
 */
class SuperstructureTest {

  @Test
  void startsIdle() {
    assertEquals(RobotState.IDLE, new Superstructure().getState());
  }

  @Test
  void fullIntakeScoreCycle() {
    Superstructure s = new Superstructure();
    assertEquals(RobotState.INTAKING, s.update(true, false, false));
    assertEquals(RobotState.INTAKING, s.update(false, false, false)); // holds
    assertEquals(RobotState.SCORING, s.update(false, true, false));
    assertEquals(RobotState.IDLE, s.update(false, true, false)); // finished scoring
  }

  @Test
  void stopAlwaysReturnsToIdle() {
    Superstructure s = new Superstructure();
    s.update(true, false, false); // INTAKING
    assertEquals(RobotState.IDLE, s.update(false, false, true));
  }

  @Test
  void stopOverridesIntakeInSameLoop() {
    assertEquals(RobotState.IDLE, new Superstructure().update(true, false, true));
  }

  @Test
  void idleIgnoresScore() {
    assertEquals(RobotState.IDLE, new Superstructure().update(false, true, false));
  }
}
