package frc.robot;

import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.XboxController;
import frc.robot.superstructure.RobotState;
import frc.robot.superstructure.Superstructure;

/**
 * WEEK 3 — driving the {@link Superstructure} state machine from real buttons.
 *
 * Note the method references (driver::getAButton, ...). Each is a BooleanSupplier
 * — a lambda the state machine asks for a value every loop. This is exactly the
 * shape command-based button bindings take, which we reach in Week 4.
 */
public class Robot extends TimedRobot {

  private final XboxController driver = new XboxController(0);
  private final Superstructure superstructure = new Superstructure();
  private RobotState lastState = RobotState.IDLE;

  public Robot() {}

  @Override
  public void teleopInit() {
    superstructure.reset();
    lastState = superstructure.getState();
    System.out.println("Teleop start — state: " + lastState.label());
  }

  @Override
  public void teleopPeriodic() {
    RobotState state =
        superstructure.update(
            driver::getAButton, // A = intake
            driver::getBButton, // B = score
            driver::getYButton); // Y = stop

    // Only print when the state actually changes (not 50x/second).
    if (state != lastState) {
      System.out.println("-> " + state.label());
      lastState = state;
    }
  }
}
