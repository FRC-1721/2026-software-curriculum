package frc.robot.superstructure;

import java.util.function.BooleanSupplier;

/**
 * WEEK 3 — a tiny state machine that decides what the robot's superstructure
 * should be doing, based on three button inputs. It demonstrates the OOP and
 * control-flow pieces command-based robot code leans on: an {@link RobotState}
 * enum, a {@code switch}, and {@link BooleanSupplier} lambdas.
 *
 * <p>Transition rules:
 * <ul>
 *   <li>the STOP button always returns to {@code IDLE}</li>
 *   <li>IDLE + intake  → INTAKING</li>
 *   <li>INTAKING + score → SCORING</li>
 *   <li>SCORING + score  → IDLE (the scoring action has finished)</li>
 * </ul>
 * Any input that doesn't match a rule leaves the state unchanged.
 */
public class Superstructure {

  private RobotState state = RobotState.IDLE;

  /** @return the current state. */
  public RobotState getState() {
    return state;
  }

  /** Forces the machine back to a known starting state. */
  public void reset() {
    state = RobotState.IDLE;
  }

  /**
   * Advances the state machine by one step given the raw button values.
   *
   * @param intakeButton whether the intake button is pressed this loop
   * @param scoreButton  whether the score button is pressed this loop
   * @param stopButton   whether the stop button is pressed this loop
   * @return the (possibly unchanged) new state
   */
  public RobotState update(boolean intakeButton, boolean scoreButton, boolean stopButton) {
    // STOP wins over everything else.
    if (stopButton) {
      state = RobotState.IDLE;
      return state;
    }

    switch (state) {
      case IDLE:
        if (intakeButton) {
          state = RobotState.INTAKING;
        }
        break;
      case INTAKING:
        if (scoreButton) {
          state = RobotState.SCORING;
        }
        break;
      case SCORING:
        if (scoreButton) {
          state = RobotState.IDLE;
        }
        break;
      default:
        // Unreachable, but a good habit: never leave a switch without a default.
        break;
    }
    return state;
  }

  /**
   * The same logic, but driven by {@link BooleanSupplier} lambdas instead of
   * plain booleans. This is exactly the shape command-based bindings use — a
   * supplier that is asked for its value each loop — so it is worth seeing early.
   *
   * @param intake supplies whether the intake button is pressed
   * @param score  supplies whether the score button is pressed
   * @param stop   supplies whether the stop button is pressed
   * @return the (possibly unchanged) new state
   */
  public RobotState update(BooleanSupplier intake, BooleanSupplier score, BooleanSupplier stop) {
    return update(intake.getAsBoolean(), score.getAsBoolean(), stop.getAsBoolean());
  }
}
