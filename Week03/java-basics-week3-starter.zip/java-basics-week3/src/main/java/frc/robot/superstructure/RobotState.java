package frc.robot.superstructure;

/**
 * WEEK 3 — an {@code enum} naming the states our robot's superstructure can be
 * in. An enum is a fixed set of named values; using one (instead of, say, the
 * numbers 0/1/2) makes the code read in plain English and makes illegal states
 * impossible to represent.
 *
 * <p>This enum also carries a human-readable label, to show that enum values
 * can hold data and behavior — not just be bare names.
 */
public enum RobotState {
  IDLE("Idle"),
  INTAKING("Intaking"),
  SCORING("Scoring");

  private final String label;

  RobotState(String label) {
    this.label = label;
  }

  /** @return a friendly name suitable for the dashboard. */
  public String label() {
    return label;
  }
}
