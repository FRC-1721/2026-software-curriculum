# Week 3 Starter / Reference — Java for FRC, part 2

FRC 1721 · WPILib 2026 · Java. Reference project for **Week 3: control flow,
enums, interfaces & lambdas**. Builds on a Timed Robot project; runs in
simulation.

## What you're learning
The OOP and control-flow pieces the command-based framework (Week 4) leans on:
an `enum`, a `switch`, and `BooleanSupplier` lambdas — all through a tiny state
machine that decides what the robot's superstructure is doing.

## What's in here
```
src/main/java/frc/robot/
├── Robot.java                          drives the state machine from A/B/Y buttons
├── Main.java                           entry point — do not edit
└── superstructure/
    ├── RobotState.java                 enum: IDLE / INTAKING / SCORING
    └── Superstructure.java             the state machine (switch + lambdas)
src/test/java/frc/robot/
└── superstructure/SuperstructureTest.java   JUnit 5 tests for the transitions
```

## The state machine
```
        intake (A)            score (B)
  IDLE ───────────► INTAKING ───────────► SCORING
   ▲                   │                     │
   │  stop (Y) from any state                │ score (B) — done
   └─────────────────────────────────────────┘
```
STOP (Y) always returns to IDLE and beats any other button in the same loop.

## The lab
1. Build the `RobotState` enum and the `Superstructure.update(...)` logic.
2. Run the tests:  **`./gradlew test`**  (Windows: `gradlew test`). All should pass.
3. Wire it in: `Robot.java` feeds the A/B/Y buttons in as `BooleanSupplier`
   lambdas (`driver::getAButton`, …) and prints the state whenever it changes.
   Simulate, set **Teleoperated**, and press the buttons in the sim's joystick
   panel to walk the machine through its states.

> **Why lambdas here?** `driver::getAButton` is a `BooleanSupplier` — a value the
> machine asks for each loop. That's the exact shape command-based button
> bindings take in Week 4, so it's worth meeting now.

## Using this pack
- **Generate fresh (recommended):** `Template → java → Timed Robot`, then drop
  these `src/` files in.
- **Reference branch:** or clone the repo's Week 3 reference (with the Gradle
  wrapper) and run it directly.

Team number is set to **1721** in `.wpilib/wpilib_preferences.json`.

## Verified
All classes and tests compile clean (`javac -Xlint:all`, Java 17); the transition
cases pass a logic harness. `Robot.java` is checked against the WPILib 2026 API.
